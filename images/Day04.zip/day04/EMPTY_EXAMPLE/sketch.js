// setup function - used for commands that need to run only once
function setup()
{
}

// draw function - used for commands that need to be repeated
function draw()
{
}
